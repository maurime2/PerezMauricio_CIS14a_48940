var Spencer = {
  age: 22,
  country: "United States"
};

// make your own object here called me
var me = {
  age: 29,
  country: "United States"
};