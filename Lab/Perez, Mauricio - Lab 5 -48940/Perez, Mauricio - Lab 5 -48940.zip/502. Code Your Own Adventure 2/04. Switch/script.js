var user = prompt("What is my input? Yes or No?").toUpperCase();

switch(troll) {
    //Case 1
        case 'FIGHT':
        break;
    //Case 2    
        case 'HIDE':
        break;    
    //Case 2    
        case 'RUN':
        break;            
    //Default case    
    default:    
    console.log("You did NOTHING!!! You were smashed on!");
    break;
    }