// Click on "Stuck? Get a hint!" if you get stuck!
var names = ["Melbourne", "Amman", "Helsinki", "NYC","Alaska"];

for (var i = 0; i < names.length; i++) {
    console.log("I know someone called " + names[i]);
}
