// Let's print out every element of an array using a for loop

var cities = ["Melbourne", "Amman", "Helsinki", "NYC","Alaska"];

for (var i = 0; i < cities.length; i++) {
    console.log("I would like to visit " + cities[i]);
}