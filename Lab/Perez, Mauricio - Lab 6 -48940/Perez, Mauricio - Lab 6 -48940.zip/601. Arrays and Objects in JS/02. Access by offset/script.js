var languages = ["HTML", "CSS", "JavaScript", "Python", "Ruby"];

console.log(languages[2]);