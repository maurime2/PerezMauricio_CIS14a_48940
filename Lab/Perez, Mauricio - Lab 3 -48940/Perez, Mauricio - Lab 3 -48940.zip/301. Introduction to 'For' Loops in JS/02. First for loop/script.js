// Example of a for loop:

for (var counter = 1; counter < 11; counter++) {
	console.log(counter);
}
