// Write your very own for loop!

for(var i = 100; i>0; i-=5){
    console.log(i);
    
    }