// Write your loop below!
for (var i=0;i<10;i++){
    console.log("Print this shizz: "+i );
    }
