// Edit this for loop

for (var i = 4; i <= 23; i = i + 1) {
	console.log(i);
}