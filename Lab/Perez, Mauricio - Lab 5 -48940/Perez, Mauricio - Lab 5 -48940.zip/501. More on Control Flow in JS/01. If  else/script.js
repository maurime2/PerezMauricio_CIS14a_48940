var isEven = function(number) {
  // Your code goes here!
    if(number%2===0){
        return true;
        }
    else{
        return false;
        }
};

isEven(2);