var i = 0;
var j = 0;
var names=["Mauri","Kathy","Jessica","Carla","Zoe","Issac"];
var names2 = [];
while (i<10){
    
    for(var j = 0;j<names.length ;j++){
        //names.push
        console.log((names[j]));
        }
    
    i++
    }
    
    //console.log(names2);