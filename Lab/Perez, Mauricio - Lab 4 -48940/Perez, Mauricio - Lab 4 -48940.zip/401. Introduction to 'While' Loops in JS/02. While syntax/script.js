var understand = true;

while( understand ){
	console.log("I'm learning while loops!");
	understand = false;
}