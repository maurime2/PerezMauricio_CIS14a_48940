//Object Constructor
var me  = {
    name: 'Mauricio',
    age: 29
};

var emptyObj = {};

//Using the constructor
var me  = new Object();

//Adding Keys
me["name"] = "Mauricio";
me.age = 29;