// You are now declaring an array.
// Arrays are an awesome data structure!
var names = ["Mao","Gandhi","Mandela"];

var sizes = [4, 6, 3, 2, 1, 9];

var mixed = [34, "candy", "blue", 11];

var junk = ["mauri","perez", 10, 17];

console.log(junk);