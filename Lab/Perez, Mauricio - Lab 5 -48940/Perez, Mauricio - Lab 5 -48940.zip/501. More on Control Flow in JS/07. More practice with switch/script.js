var answer = prompt("What is the meaning of life?");

switch(answer) {
  case '42':
    console.log("You are wise beond your years!!!");
    break;
  // Add your code here!
    case 'jellow':
    console.log("BOW...No more pudding pops for you sicko!!!");
    break;
//Default
    default:
    console.log("DOSE NOT COMPUTE!!!");
    
}