function Cat(age, color) {
  this.age = age;
  this.color = color;
}

// make a Dog constructor here
function Dog(name,age) {
  this.name = name;
  this.age = age;
}