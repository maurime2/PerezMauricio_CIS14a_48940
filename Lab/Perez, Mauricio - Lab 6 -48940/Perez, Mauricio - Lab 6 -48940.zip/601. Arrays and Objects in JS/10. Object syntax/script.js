var me = {
    name : 'Mauricio',
    age  : 29
};