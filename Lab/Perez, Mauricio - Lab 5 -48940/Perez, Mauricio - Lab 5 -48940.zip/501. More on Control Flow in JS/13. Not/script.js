// Declare your variables here!
var programming = false;


var happy = function() {
  // Add your if/else statement here!
  if(programming != false){
      console.log("Happy Happy joy joy!!!");
      return false;
      }
      else{
          console.log("NO JOy :-(");
          return true;
          }
};