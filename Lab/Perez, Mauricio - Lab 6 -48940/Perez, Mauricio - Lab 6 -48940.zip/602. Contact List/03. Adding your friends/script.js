//object: Friends
var friends = {};

//Adding Bill and Steve
friends.bill = {}
friends.steve = {}