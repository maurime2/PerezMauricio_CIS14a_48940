//Remember to set your condition outside the loop!


var loop = function(){
    var i=0;
	while(i<3){
		//Your code goes here!
		console.log("I'm looping!");
		i++;
	}
};

loop();