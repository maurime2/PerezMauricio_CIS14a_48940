// Define quarter here.
var quarter = function(number){
    return number/4;
    }

var number = 12;


if (quarter(number) % 3 === 0 ) {
  console.log("The statement is true");
} else {
  console.log("The statement is false");
}
