/*jshint multistr:true */
var text   = "Mauri Mauri Mauri Mauri";
var myName = "Mauri";
var hits = [];

for(i=0;i<text.length;i++){
    if (text[0]==='M'){
        
        }
    }