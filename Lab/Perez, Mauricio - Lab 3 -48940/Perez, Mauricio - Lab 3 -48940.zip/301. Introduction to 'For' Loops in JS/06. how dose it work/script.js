// Example for loop

for (var i = 8 ; i < 120; i+=12) {
	console.log(i);
}