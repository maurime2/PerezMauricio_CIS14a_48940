//Object Constructor
var me  = {
    name: 'Mauricio',
    age: 29
};

//Array with all 4
var myArray = [29, false, 'mauri', me];