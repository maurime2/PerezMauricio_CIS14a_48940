// Write your foodDemand function below.
// Last hint: In your reusable block of code, end each line
// with a semicolon (;)
var foodDemand = function(food) {
    // code code code
    // code code code
    // (more lines of code)
    console.log("I want to eat" + " " + food);
};

var food = "Enchiladas";
foodDemand(food);