//Object Constructor
var me  = {
    name: 'Mauricio',
    age: 29
};

//Jagged Array with Constructor 
var newArray = [[1, 4, 2], [me]];