understand = true;

while(understand){
	console.log("I'm learning while loops!");
	//Change the value of 'understand' here!
	var understand = false;
	
}