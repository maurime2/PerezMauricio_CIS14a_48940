// Nicely written function:
var calculate = function (number) {
    var val = number * 10;
    console.log(val);
};

// Badly written function with syntax errors!

 var greeting = function (name){
     console.log(name);
}; 
var name = "Mauricio";
greeting(name);