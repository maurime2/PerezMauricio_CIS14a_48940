// Change where the for loop starts.

for (var i = 5; i < 11; i = i + 1){
	console.log(i);
}