var myObj = {
    // finish myObj
    name: "Mauricio",
    //nickname: "MauriMe"
};

console.log( myObj.hasOwnProperty('name') ); // should print true
console.log( myObj.hasOwnProperty('nickname') ); // should print false