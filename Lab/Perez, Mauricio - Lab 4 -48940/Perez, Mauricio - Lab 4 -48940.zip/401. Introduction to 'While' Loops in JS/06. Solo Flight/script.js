//Remember to make your condition true outside the loop!

var soloLoop = function(){
  var i=0;
  while (i<1){
  //Your code goes here!
  console.log("Looped once!");
  i++;
  }
};

soloLoop();