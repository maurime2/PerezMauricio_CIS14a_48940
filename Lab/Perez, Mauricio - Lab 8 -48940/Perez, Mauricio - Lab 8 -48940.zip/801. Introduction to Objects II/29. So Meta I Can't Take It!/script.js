// what is this "Object.prototype" anyway...?
var prototypeType = typeof Object.prototype;
console.log( prototypeType);

// now let's examine it!
var hasOwn = Object.prototype.hasOwnProperty("hasOwnProperty");
console.log(hasOwn);