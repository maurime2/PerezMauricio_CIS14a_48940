//Object Constructor
var object1  = {
    name: 'Mauricio',
    age: 29
};

//Object Constructor
var object2  = {
    name: 'Mauricio',
    age: 29
};

//Object Constructor
var object3  = {
    name: 'Mauricio',
    age: 29
};