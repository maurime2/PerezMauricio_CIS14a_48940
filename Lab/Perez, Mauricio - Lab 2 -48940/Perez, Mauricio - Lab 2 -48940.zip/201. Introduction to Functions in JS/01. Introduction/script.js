var speed = 65;

// Complete the condition in the ()s on line 4
if (speed>80 ) {
	// Use console.log() to print "Slow down"
	console.log("Slow down"); 
} 
else {
	// Use console.log() to print "Drive safe"
    console.log("Drive safe");

}