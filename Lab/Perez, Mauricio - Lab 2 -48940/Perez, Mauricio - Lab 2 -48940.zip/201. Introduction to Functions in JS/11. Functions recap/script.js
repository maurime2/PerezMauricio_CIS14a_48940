var nameString = function ( name ) {
	return "Hi, I am" + " " + name;
	
};


var name  = "Mauricio";

console.log(nameString(name));