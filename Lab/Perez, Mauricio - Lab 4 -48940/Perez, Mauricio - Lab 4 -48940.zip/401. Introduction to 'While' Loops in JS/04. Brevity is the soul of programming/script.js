var bool = true;

while(bool){
    console.log("Less is more!");
    bool = false;
}