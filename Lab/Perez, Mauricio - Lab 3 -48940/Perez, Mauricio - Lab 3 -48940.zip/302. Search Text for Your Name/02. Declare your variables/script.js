/*jshint multistr:true */
var text   = "Mauri Mauri Mauri Mauri";
var myName = "Mauri";
var hits = [];

