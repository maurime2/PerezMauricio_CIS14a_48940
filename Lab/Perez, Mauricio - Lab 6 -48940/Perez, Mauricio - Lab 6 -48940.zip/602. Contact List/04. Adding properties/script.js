//object: Friends
var friends = {};

//Adding Bill and Steve
friends.bill = {
    //Properties of Bill
    firstName: "Bill",
    lastName: "Gates",
    number: "(206) 555-5555",
    
    };
friends.steve = {
    //Properties of Steve
    firstName: "Steve",
    lastName: "Jobs",
    number: "(408) 555-5555",
    };