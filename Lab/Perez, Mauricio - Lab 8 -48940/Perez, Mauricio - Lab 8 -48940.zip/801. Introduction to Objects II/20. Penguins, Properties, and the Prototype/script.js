function Penguin(name) {
    this.name = name;
    this.numLegs = 2;
}

// create your Emperor class here and make it inherit from Penguin
function Emperor(name) {
    this.name=name;
    }
    Emperor.prototype = new Penguin();

// create an "emperor" object and print the number of legs it has
var emperor = new Penguin("emperor");
console.log(emperor.numLegs);