var user = prompt("What is my input? Yes or No?").toUpperCase();
//.toLowerCase()