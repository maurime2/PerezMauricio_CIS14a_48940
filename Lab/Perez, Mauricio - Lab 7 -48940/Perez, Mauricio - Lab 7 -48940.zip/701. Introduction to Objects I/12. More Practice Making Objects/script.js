var bicycle = {
    speed : 0,
    gear : 1,
    frame_material: "carbon fiber"
    }