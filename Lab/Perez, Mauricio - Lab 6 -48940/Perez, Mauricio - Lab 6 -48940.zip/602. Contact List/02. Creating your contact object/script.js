//object: Friends
var friends = {};