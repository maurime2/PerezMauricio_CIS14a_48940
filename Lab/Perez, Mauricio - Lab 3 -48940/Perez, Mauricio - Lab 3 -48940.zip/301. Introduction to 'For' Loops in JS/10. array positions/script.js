// Practice array!

var junkData = ["Eddie Murphy", 49, "peanuts", 31];

console.log(junkData[3]);