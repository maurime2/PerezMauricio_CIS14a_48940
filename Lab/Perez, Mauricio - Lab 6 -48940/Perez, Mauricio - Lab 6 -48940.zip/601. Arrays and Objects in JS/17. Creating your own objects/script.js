var myOwnObject = {
    name : 'Mauricio',
    age  : 29
};

var emptyObj = {};

//Using the constructor
var myOwnObject  = new Object();

//Adding Keys
myOwnObject["name"] = "Mauricio";
myOwnObject.age = 29;