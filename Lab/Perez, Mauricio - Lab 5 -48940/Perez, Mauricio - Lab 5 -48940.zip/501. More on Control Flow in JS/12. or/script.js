// Declare your variables here!
var tired  = true;
var bored = false;

var nap = function() {
  // Add your if/else statement here!
  if (tired  || bored){
      cosole.log("You must be a Jessica!");
        return true;
      }
      else{
        cosole.log("You must be a Mauri!");
        return false;  
          }
};