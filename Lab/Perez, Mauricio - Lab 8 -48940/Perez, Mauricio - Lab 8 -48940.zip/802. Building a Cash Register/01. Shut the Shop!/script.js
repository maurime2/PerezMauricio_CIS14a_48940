//Create the object called cashRegister 
//and initialize its total property
var cashRegister = {
     total: 0
    };

//Using dot notation change the total property
    cashRegister.total = 2.99;