// Accepts a number x as input and returns its square
var multiply = function (x,y) {
  return x * y;
};

// Write the function multiply below
// It should take two parameters and return the product


console.log(multiply(4,5));