// Write your function starting on line 3
var perimeterBox  = function(length,width){
    return length + length + width + width;
    };
    
var length = 5;
var width = 2;
perimeterBox(length,width);