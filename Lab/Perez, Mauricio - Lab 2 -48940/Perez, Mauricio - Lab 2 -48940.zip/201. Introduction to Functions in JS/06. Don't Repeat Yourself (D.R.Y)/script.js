var  orangeCost = function(cost){
    var oranges = 5;
    console.log(oranges*cost);
    };
    
    var cost = 2.50;
    orangeCost(cost);