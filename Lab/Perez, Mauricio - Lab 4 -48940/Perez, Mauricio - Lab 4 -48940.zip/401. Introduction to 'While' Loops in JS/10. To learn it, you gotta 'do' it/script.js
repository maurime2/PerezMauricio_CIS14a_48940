var getToDaChoppa = function(){
  // Write your do/while loop here!
  var condition = false;
  do{
      console.log("Do it NOw!!!");
    }while(condition);
};

getToDaChoppa();