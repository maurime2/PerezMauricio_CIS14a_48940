var languages = ["HTML", "CSS", "JavaScript", "Python", "Ruby"];

for(i=0;i<languages.length;i++){
    console.log(languages[i]);
    }