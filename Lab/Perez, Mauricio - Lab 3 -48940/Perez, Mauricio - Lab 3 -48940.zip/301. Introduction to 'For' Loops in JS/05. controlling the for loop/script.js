// Edit this for loop!

for (var i = 5; i <= 50; i+=5) {
	console.log(i);
}